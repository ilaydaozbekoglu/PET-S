package com.example.petsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.petsapp.databinding.ActivityMainBinding;
import com.example.petsapp.databinding.ActivityVetHesapolusturBinding;

public class vet_hesapolustur extends AppCompatActivity {

    ActivityVetHesapolusturBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_vet_hesapolustur);
        binding = ActivityVetHesapolusturBinding.inflate(getLayoutInflater());
        View view  = binding.getRoot();
        setContentView(view);

        binding.btnKaydol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hesap_kontrol();
            }
        });
    }

    public void hesap_kontrol(){
        if(binding.txtVetadi.getText().toString().trim().length()==0){
            Toast.makeText(vet_hesapolustur.this, "Klinik adı girişi yapmadınız", Toast.LENGTH_LONG).show();
        }
        else if (binding.txtVetEmail.getText().toString().trim().length()==0){
            Toast.makeText(vet_hesapolustur.this, "Email girişi yapmadınız", Toast.LENGTH_LONG).show();
        }
        else if(binding.txtPhoneVet.getText().toString().trim().length()==0){
            Toast.makeText(vet_hesapolustur.this, "Telefon Numarası girişi yapmadınız", Toast.LENGTH_LONG).show();
        }
        else if(binding.txtVetadres.getText().toString().trim().length()==0){
            Toast.makeText(vet_hesapolustur.this, "Klinik adres girişi yapmadınız", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(vet_hesapolustur.this, "Hesabınız başarıyla oluşturuldu. ID:" + "veterinerId", Toast.LENGTH_LONG).show();
        }

    }


}